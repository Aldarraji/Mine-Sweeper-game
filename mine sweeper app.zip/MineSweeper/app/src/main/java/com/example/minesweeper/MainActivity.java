package com.example.minesweeper;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.service.quicksettings.Tile;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Toast;

import java.util.Random;

class MineSweeper1View extends View {

    boolean isbomb[][];

    Context activityContext;

    private String tag = "AA";

    private int touchX;
    private int touchY;
    //private float touchX;
    //private float touchY;

    private final int XBASE = 40;
    private final int YBASE = 80;

    private final int BW = 40;
    private final int BH = 40;

    private final int ROWS = 10;
    private final int COLS = 10;

    private final int NUMBOMBS = 12;

    private final int TILE = 10;
    private final int EMPTY = 11;
    private final int FLAG = 12;
    private final int BOMB = 13;
    //private int count;

    private long mouseUP=0;                // new to Graphics4
    private long mouseDOWN=0;              // new to Graphics4
    boolean longPress = false;

    private int flags_remaining = NUMBOMBS;
    private boolean game_over = false;

    private int status[][];

    Bitmap empty_image;
    Bitmap tile_image;
    Bitmap flag_image;
    Bitmap bomb_image;

    private Bitmap[] imagArray = new Bitmap[]{BitmapFactory.decodeResource(getResources(), R.mipmap.empty),BitmapFactory.decodeResource(getResources(), R.mipmap.bluenum1), BitmapFactory.decodeResource(getResources(), R.mipmap.bluenum2),
            BitmapFactory.decodeResource(getResources(), R.mipmap.bluenum3), BitmapFactory.decodeResource(getResources(), R.mipmap.bluenum4), BitmapFactory.decodeResource(getResources(), R.mipmap.bluenum5),
            BitmapFactory.decodeResource(getResources(), R.mipmap.bluenum6), BitmapFactory.decodeResource(getResources(), R.mipmap.bluenum7),BitmapFactory.decodeResource(getResources(), R.mipmap.bluenum8)};

    String str = "";

    private class RowCol {
        public int row;
        public int col;
    }

    private void print(String s) {
        Log.i(tag, s);
        //Toast.makeText(activityContext, s, 1).show();
    }

    public MineSweeper1View(Context context) {
        super(context);

        activityContext = context;

        print("MineSweeperView constructor:");

        isbomb = new boolean[ROWS][COLS];

        status = new int[ROWS][COLS];

        for (int i = 0; i < ROWS; i++) {
            for (int j = 0; j < COLS; j++) {
                status[i][j] = TILE;
            }
        }
        int count2 = 0;
        Random rand = new Random();
        while(count2 < NUMBOMBS) {
            int r = rand.nextInt(ROWS);
            int c = rand.nextInt(COLS);

            if(isbomb[r][c] == false ) {
                isbomb[r][c] = true;
                //status[r][c] = BOMB;
                count2++;
            }
        }

        empty_image = BitmapFactory.decodeResource(getResources(), R.mipmap.empty);
        tile_image = BitmapFactory.decodeResource(getResources(), R.mipmap.tile);
        flag_image = BitmapFactory.decodeResource(getResources(), R.mipmap.flag);
        bomb_image = BitmapFactory.decodeResource(getResources(), R.mipmap.bomb);
    }

    private RowCol getIndex(int x, int y)
    {
        RowCol rc = new RowCol();

        // use x, y and XBASE, YBASE, ROWS, COLS, BW, BH to validate x & y!
        // calculate row and column index given x and y coordinates
        //<snip!>

        //x = touchX - XBASE/BW;
        //y = touchY - YBASE/BH;

        if ((x < XBASE) ||
                (x > BW * COLS + XBASE) ||
                (y < YBASE) ||
                (y > BH * ROWS + YBASE) ) {
            rc.row = -1;
            rc.col = -1;
            return rc;
        }

        rc.row = (y - YBASE) / BH;
        rc.col = (x - XBASE) / BW;

        print("getIndex: r = " + rc.row + ", c = " + rc.col);

        return rc;
    }

    private int countNeighboringBombs(int r, int c)
    {
        int count = 0;

        //check top row
        if ((r>0) && (c>0) && (isbomb[r-1][c-1])) count++;
        if ((r>0) && (isbomb[r-1][c])) count++;
        if ((r>0) && (c<COLS-1) && (isbomb[r-1][c+1])) count++;

        //check middle row
        if ((c>0) && (isbomb[r][c-1])) count++;
        if ((c<COLS-1) && (isbomb[r][c+1])) count++;

        //check bottom row
        if ((r<ROWS-1) && (c>0) && (isbomb[r+1][c-1])) count++;
        if ((r<ROWS-1) && (isbomb[r+1][c])) count++;
        if ((r<ROWS-1) && (c<COLS-1) && (isbomb[r+1][c+1])) count++;
        return count;
    }

    private void clearBlankNeighbors(int r, int c) {
        status[r][c] = EMPTY;

        int n = countNeighboringBombs(r, c);

        if (n == 0) {
            for (int i = -1; i <= 1; i++) {
                for (int j = -1; j <= 1; j++) {
                    // Clear rows & columns if the tile
                    // has not already been EMPTY
                    if ((r + i < ROWS) && (r + i >= 0) && (c + j < COLS) && (c + j >= 0) &&
                            (status[r + i][c + j] == TILE)) {
                        // Recursive call to clear open tiles.
                        clearBlankNeighbors(r + i, c + j);
                    }
                }
            }

        } else {
            status[r][c] = n;
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        if(game_over) return true;
        print("onTouchEvent");
        touchX = (int) e.getX();
        touchY = (int) e.getY();
        Paint fg = new Paint();
        int action = e.getAction();
        //print("onTouchEvent: x = " + touchX + ", y = " + touchY);

        RowCol rc;
        rc = getIndex(touchX, touchY);
        int count = countNeighboringBombs(rc.row, rc.col);

            if (action == MotionEvent.ACTION_DOWN) {
                mouseDOWN = System.currentTimeMillis();
                invalidate();
            } else if (action == MotionEvent.ACTION_UP) {
                mouseUP = System.currentTimeMillis();
                if (mouseUP - mouseDOWN > 200) {
                    print("LONG PRESS!");
                    longPress = true;

                    rc = getIndex(touchX, touchY);
                    if (rc.row != -1 && rc.col != -1) {
                        if (status[rc.row][rc.col] == TILE) {
                            status[rc.row][rc.col] = FLAG;
                            invalidate();
                        } else {
                            status[rc.row][rc.col] = TILE;
                            invalidate();
                        }
                    }
                    return super.onTouchEvent(e);

                    //if longpress false replace tile/bomb check/game_over check
                } else {
                    longPress = false;

                    if (rc.row != -1 && rc.col != -1) {

                        if (status[rc.row][rc.col] == FLAG) {
                            status[rc.row][rc.col] = FLAG;
                            invalidate();
                        } else {
                            status[rc.row][rc.col] = EMPTY;
                            invalidate();
                        }

                        //verify if bomb under tile/end game or continue by placing #tile
                        if (isbomb[rc.row][rc.col] == true) {
                            status[rc.row][rc.col] = BOMB;
                            game_over = true;
                            String s = "Game Over!";
                            Toast.makeText(activityContext, s, Toast.LENGTH_LONG).show();
                            invalidate();

                        } else {
                            imagArray[count] = imagArray[count];
                            invalidate();
                        }
                        //else
                        if (game_over == false) {

                            int tileCount = 0;
                            //loop to count tiles left
                            for (int i = 0; i < ROWS; i++) {
                                for (int j = 0; j < COLS; j++) {
                                    if (status[i][j] == TILE) {
                                        tileCount++;
                                    }
                                }
                            }
                            print("tilecount = " + (Integer.toString(tileCount)));

                            //call to clear blank neighbors
                            int n = countNeighboringBombs(rc.row, rc.col);
                            if (n > 0) {
                                status[rc.row][rc.col] = n;
                            } else {
                                clearBlankNeighbors(rc.row, rc.col);
                            }

                            //check to see if winner
                            if ((0 == tileCount) && (FLAG == NUMBOMBS)) {
                                String end = "You Won!!!!";
                                Toast.makeText(activityContext, end, Toast.LENGTH_LONG).show();
                                game_over = true;
                            }
                        }
                    }
                    return super.onTouchEvent(e);
                }
            }
        return true;
    }




    @Override
    public void onDraw(Canvas canvas) {

        Paint fg = new Paint();
        int w = getWidth();
        int h = getHeight();
        print("onDraw: w = " + w + ", h = " + h);

            canvas.drawColor(Color.WHITE);
            fg.setColor(Color.BLACK);

            int y = 0;
            y = (y - YBASE) / BH;
            int x = 0;
            x = (x - XBASE) / BW;
            
        for (int i = 0; i < ROWS; i++) {
            for (int j = 0; j < COLS; j++) {
                int count = countNeighboringBombs(i, j);
                if (status[i][j] == TILE) {
                    canvas.drawBitmap(tile_image, (XBASE + (j * BW)), (YBASE + (i * BH)), null);
                    //print("tile worked");
                } else if (status[i][j] == EMPTY) {
                    //canvas.drawBitmap(empty_image, ixbase, ybase, null);
                    canvas.drawBitmap(empty_image, (XBASE + (j * BW)), (YBASE + (i * BH)), null);
                }
                else if(status[i][j] == FLAG) {
                    canvas.drawBitmap(flag_image,  (XBASE + (j * BW)), (YBASE + (i * BH)), null);
                }
                else if(status[i][j] == BOMB)  {
                    canvas.drawBitmap(bomb_image,  (XBASE + (j * BW)), (YBASE + (i * BH)), null);
                }
                //display the blue numbers
                else if(status[i][j] > 0 && status[i][j] < 9) {
                    canvas.drawBitmap(imagArray[count],  (XBASE + (j * BW)), (YBASE + (i * BH)), null);
                }

                //just to print the borders
                else if (longPress)                                                                                   // new to Graphics4
                    canvas.drawText("x = " + touchX + ", y = " + touchY + " (LONGPRESS)", touchX, touchY, fg);   // new to Graphics4
                   //canvas.drawBitmap(flag_image,  XBASE + (i * BW), YBASE + (j * BH), null);
                else                                                                                             // new to Graphics4
                    canvas.drawText("x = " + touchX + ", y = " + touchY + "count= " + count, touchX, touchY, fg);
            }
        }
        fg.setStrokeWidth(2);
        // Horizontal Lines
        canvas.drawLine(XBASE - 2, YBASE - 2, COLS*BW + XBASE + 2, YBASE - 2, fg);
        canvas.drawLine(XBASE - 2, YBASE - 2, XBASE - 2, ROWS*BH + YBASE + 2, fg);

        // Vertical Lines
        canvas.drawLine(XBASE - 2, ROWS*BH + YBASE + 2, COLS*BW + XBASE + 2, ROWS*BH + YBASE + 2, fg);
        canvas.drawLine(COLS*BW + XBASE + 2, YBASE - 2, COLS*BW + XBASE + 2, ROWS*BH + YBASE + 2, fg);

            fg.setTextSize(24);
    }
}

public class MainActivity extends AppCompatActivity {

    private String tag = "AA";

    MineSweeper1View mineSweeper1View;

    private void print(String s)
    {
        Log.i(tag, s);
        //Toast.makeText(this, s, 1).show();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        print("onCreate:");
        Toast.makeText(this, "MineSweeper1", Toast.LENGTH_SHORT).show();

        mineSweeper1View = new MineSweeper1View(this);
        setContentView(mineSweeper1View);
    }
}

